package com.nyp.sit.itm154.mybreadbuilder

import android.app.*
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.support.v4.app.NotificationCompat
import android.support.v7.app.AppCompatActivity
import android.view.ContextMenu
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*


//TODO 1.3: Implement DialogInterface.OnDismissListener

class MainActivity : AppCompatActivity(), DialogInterface.OnDismissListener {

    override fun onDismiss(dialog: DialogInterface?){
        tvOrder.text = myOrder
    }
    companion object {
        val BREAD_CHOICE_DIALOG = 1
        val TOPPING_CHOICE_DIALOG = 2
        val SAUCE_CHOICE_DIALOG = 3
        var breadSelected = ""
        var toppingSelected = ArrayList<Int>()
        var sauceSelected = -1
        // Global variables to all String Array Resource
        var mBreadArray: Array<String>? = null
        var mToppingArray: Array<String>? = null
        var mSauceArray: Array<String>? = null
        var myOrder = ""

        //TODO 2.1: Create notification id
        val MY_NOTIFICATION_ID = 1050

        fun updateOrder(): String {

            myOrder = ""
            if (breadSelected.length > 0)
                myOrder = "Bread: " + breadSelected

            if (toppingSelected.size > 0) {

                myOrder += "\nTopping: "

                repeat(toppingSelected.size) {

                    myOrder += mToppingArray?.get(toppingSelected.get(it)) + ", "
                }

            }



            if (sauceSelected > 0) {

                myOrder += "\nSauce: " + mSauceArray?.get(sauceSelected)
            }

            return myOrder

        }
    }

    //TODO 1.4: override onDismiss to update tvOrder


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mBreadArray = resources.getStringArray(R.array.bread_choice)
        mToppingArray = resources.getStringArray(R.array.topping_choice)
        mSauceArray = resources.getStringArray(R.array.sauce_choice)


        tvBread.setOnClickListener {


            //TODO 1.5: Create MyBreadDialog of type BREAD_CHOICE_DIALOG
            var dialog = MyBreadDialog()
            dialog.setDialogType(BREAD_CHOICE_DIALOG)
            dialog.show(supportFragmentManager,"MyBreadDialog")

        }

        tvTopping.setOnClickListener {

            //TODO 1.6: Create MyBreadDialog of type TOPPING_CHOICE_DIALOG
            var dialog = MyBreadDialog()
            dialog.setDialogType(TOPPING_CHOICE_DIALOG)
            dialog.show(supportFragmentManager, "MyBreadDialog")

        }

        tvSauce.setOnClickListener {
            //TODO 1.7: Create MyBreadDialog of type SAUCE_CHOICE_DIALOG
            var dialog = MyBreadDialog()
            dialog.setDialogType(SAUCE_CHOICE_DIALOG)
            dialog.show(supportFragmentManager,"MyBreadDialog")


        }


        btnStartBaking.setOnClickListener {
            //TODO 2.2: Create Notification Manager handler
            var notifyManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            //TODO 2.3: Create Notification Channel
            val notificationChannel =
                NotificationChannel("unique_channel_id", "channel_name", NotificationManager.IMPORTANCE_DEFAULT)
            notifyManager.createNotificationChannel(notificationChannel)
            var notifyBuilder = NotificationCompat.Builder(applicationContext,"unique_channel_id")

            notifyBuilder.setContentTitle("Bread Builder")
            notifyBuilder.setContentText("Baking in progress")
            notifyBuilder.setSmallIcon(R.drawable.icon_bread)
            //TODO 2.4: Thread to emulate long process which updates notification

            Thread(Runnable {
                var i: Int
                //Simulate a lengthy operation
                i = 0
                while (i <= 100) {
                    //Sets the progress bar to a max value, the
                    //current completion percentage, and "determinate" state
                    notifyBuilder.setProgress(100, i, false)
                    //Displays the notitification progress for the first time
                    notifyManager.notify(MY_NOTIFICATION_ID,notifyBuilder.build())
                    //Sleeps the thread, simulating an operation
                    try {
                        //Sleep for    1  second
                        Thread.sleep((1 * 1000).toLong())
                    } catch (e: InterruptedException) {
                        //Do nothing
                    }
                    i += 10
                }
                //Update the notification when the loop finishes
                notifyBuilder.setContentText("Bread is ready!")
                //Removes the progress bar
                notifyBuilder.setProgress(0, 0, false)
                //Show the notification with completed message
                notifyManager.notify(MY_NOTIFICATION_ID, notifyBuilder.build())
                }
                    //Starts the thread by calling the run() method
                ).start()

                }

    }

    //TODO 1.1 : Update MyBreadDialog to extend DialogFragment
    // - Override onCreateDialog function to create the dialog
    // - Create the AlertDialog.Builder
    // - if dialogType is Bread choice dialog, display the different bread choice
    // - if dialogType is Topping choice dialog, display the different toppings
    // - if dialogType is Sauce choice dialog, display the different sauces

    //TODO 1.2: Override onDismiss method
    class MyBreadDialog() : DialogFragment() {

        var dialogType: Int? = null

        fun setDialogType(type: Int) {

            dialogType = type

        }


        override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
            var builder = AlertDialog.Builder(activity)
            if (dialogType == BREAD_CHOICE_DIALOG) {
                builder.setTitle("Bread Choice")
                builder.setItems(R.array.bread_choice, { dialog: DialogInterface?, which: Int ->
                    if (mBreadArray != null) {
                        breadSelected = mBreadArray!!.get(which)
                        updateOrder()
                    }
                })
            } else if (dialogType == TOPPING_CHOICE_DIALOG) {
                if (mToppingArray != null) {
                    builder.setTitle("Topping Choice")
                    var checkedValues = BooleanArray(mToppingArray!!.size)
                    repeat(toppingSelected.size)
                    {
                        checkedValues[toppingSelected[it]] = true
                    }
                    builder.setMultiChoiceItems(R.array.topping_choice, checkedValues, ({ dialog, which, isChecked ->
                        if (isChecked) {
                            toppingSelected.add(which)
                        } else if (toppingSelected.contains(which)) {
                            toppingSelected.remove(which)
                        }
                    }))

                }
                builder.setPositiveButton("OK", { dialog, which ->
                    updateOrder()
                })

            } else if (dialogType == SAUCE_CHOICE_DIALOG) {
                builder.setSingleChoiceItems(R.array.sauce_choice, sauceSelected, { dialog, which ->
                    sauceSelected = which
                })
                builder.setPositiveButton("OK", { dialog, which ->
                    updateOrder()
                })
            }
            return builder.create()
        }


        override fun onDismiss(dialog: DialogInterface?) {
            super.onDismiss(dialog)
            val activity = activity
            if(activity is DialogInterface.OnDismissListener){
                (activity as DialogInterface.OnDismissListener).onDismiss(dialog)
            }
        }

        }

}
